package com.example.scalculator.Model;

public class Chatslist {

    String id;

    public Chatslist(String id) {
        this.id = id;
    }


    public Chatslist() {
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }
}
